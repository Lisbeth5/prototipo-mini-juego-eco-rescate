export const globals = {
    score: 0,
    level: 1,
    timeLeft: 60
};